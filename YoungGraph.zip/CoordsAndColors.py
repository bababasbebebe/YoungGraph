
def Shapin():

	with open("SortedCoordsAndDims.txt", "r") as f1, open("ColoredCoords.txt", "r") as f2, open("CoordsAndColors.txt", "w") as w:

		numofrows = sum(1 for line in f1)
		f1.seek(0)
		file1 = f1.readlines()
		file2 = f2.readlines()
		
		for i in range(numofrows):
			if len(file1[i]) != 1:
				w.writelines(file1[i][:file1[i].find('|')]+' '+file2[i])
			else:
				w.writelines('\n')


