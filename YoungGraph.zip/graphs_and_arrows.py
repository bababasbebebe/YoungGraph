from math import sqrt
import sys
import os
import matplotlib.pyplot as plt
from matplotlib import transforms
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
import matplotlib.patches as patches
import matplotlib.cm as cm
import Dyefile
import Sortfile
import CoordsAndColors
import time

razm = []
x = []
y = []
x1 = []
y1 = []
x2 = []
y2 = []
x1j = []
y1j = []
x2j = []
y2j = []
colorj = []
color = []
x_j = []
y_j = []

			

key_color = sys.argv[1]
key_max = sys.argv[2]
key_arrows = sys.argv[3]
file_boxes = sys.argv[4]
file_arrows = sys.argv[5]
graph_name = sys.argv[6]
file_color = sys.argv[7]
aw = sys.argv[8]
bw = sys.argv[9]
g_ar = sys.argv[10]


if aw == "0":
	aw = 0.1
if bw == "0":
	bw = 0.1

if file_boxes == "0":
	with open("N.txt", "r") as f:
		for line in f:
			fl = float(line[:len(line)-1])
	file_boxes = "SomeText.txt"

			
if file_arrows == "0":
	file_arrows = "SomeText2.txt"

i = 0

Sortfile.sort(file_boxes)
if file_color == "0":
	Dyefile.Dye()
CoordsAndColors.Shapin()

with open("SortedCoordsAndDims.txt", "r") as f:
    for line in f:
        if len(line) > 1:
            x.append(float(line[:line.find(' ')]))
            y.append(float(line[line.find(' ')+1:line.find('|')]))
            razm.append(line[line.find('|')+1:len(line)-1])
            
with open("Jadn.txt", "r") as f:
    for line in f:
        if len(line) > 1:
            x_j.append(float(line[:line.find(' ')]))
            y_j.append(float(line[line.find(' ')+1:len(line)-1]))
if g_ar != "0":
	with open("JadnArrows.txt", "r") as f:
   	 for num, line in enumerate(f):
        	if len(line) > 1:
        	    if(num % 2 == 0):
        	        i = 0
        	        while(line[i] != ' '):
        	            i += 1
        	        x1j.append(float(line[:i]))
        	        y1j.append(float(line[i+1:len(line)-1]))
        	    else:
        	        i = 0
        	        while(line[i] != ' '):
        	            i += 1
        	        x2j.append(float(line[:i]))
        	        y2j.append(float(line[i+1:len(line)-1]))


with open(file_arrows, "r") as f:
    for num, line in enumerate(f):
        if len(line) > 1:
            if(num % 2 == 0):
                i = 0
                while(line[i] != ' '):
                    i += 1
                x1.append(float(line[:i]))
                y1.append(float(line[i+1:len(line)-1]))

            else:
                i = 0
                while(line[i] != ' '):
                    i += 1
                x2.append(float(line[:i]))
                y2.append(float(line[i+1:len(line)-1]))

with open('ColoredCoords.txt', 'r') as f:   
    for line in f:
        if(len(line)>1):
            color.append(line[:7])

fig,ax=plt.subplots()

for i in range(len(x)):
    if(key_color == '1'):
            rect = patches.Rectangle((x[i],y[i]), 1, 1, edgecolor='black', facecolor = color[i], lw =  float(bw))
            ax.add_patch(rect)
    if(key_max == '1'):
        if(color[i] == "#ff0000"):
            rect = patches.Rectangle((x[i],y[i]), 1, 1, edgecolor='black', facecolor = 'yellow', lw =  float(bw))
            ax.add_patch(rect)
        elif(key_color == '0'): 
            rect = patches.Rectangle((x[i],y[i]), 1, 1, edgecolor='black', facecolor = 'white', lw =  float(bw))
            ax.add_patch(rect)
    if(key_max == '0' and key_color == '0'):
        rect = patches.Rectangle((x[i],y[i]), 1, 1, edgecolor='black', facecolor = 'white', lw = float(bw))
        ax.add_patch(rect)
 

    #ax.text(x[i]+0.5, y[i]+0.5, razm[i], fontsize = 6)
    #plt.pause(0.001)
    #ax.axis('equal')

#if(key_zhadn == 'y'):
#    for i in range(len(x_j)):
#        l1 = [x_j[i], x_j[i], x_j[i]+1]
#        l2 = [y_j[i], y_j[i]+1, y_j[i]]
#        ax.fill(l1, l2, color = 'black')
     
        

if(key_arrows == '1'):
    for i in range(len(x1)):
#    	if(color[i] == "#ff0000"):
    	
#    		plt.plot((x1[i]+0.5, x2[i]+0.5), (y1[i]-0.2, y2[i]+0.2), color = 'yellow', lw =  float(aw))
   # 	else:
        plt.plot((x1[i]+0.5, x2[i]+0.5), (y1[i]-0.2, y2[i]+0.2), color = 'black', lw =  float(aw))
        #plt.pause(0.001)
        #ax.axis('equal')

if(g_ar != "0"):
	j = 0      
	for i in range(len(x1j)):
		if(i+1 < len(y1j)-1):
				if(y2j[i] < y1j[i+1]):
					if(j+1 < len(colorj)):
						j += 1    
		plt.plot((x1j[i]+0.5, x2j[i]+0.5), (y1j[i]-0.2, y2j[i]+0.2), color = "#ffff00", lw = float(aw))   

ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.spines['left'].set_visible(False)
ax.spines['bottom'].set_visible(False)
plt.axis('off')

#ax.axis('scaled')
ax.axis('equal')
if(graph_name == "0"): 
	graph_name = "Graph"
	
	
plt.savefig(graph_name + ".pdf", bbox_inches = 'tight', dpi=1200)

os.system("pdfcrop " + graph_name + ".pdf")




