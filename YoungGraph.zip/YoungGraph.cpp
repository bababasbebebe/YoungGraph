#include <iostream>
#include <vector> 
#include <set>
#include <map>
#include <math.h>
#include <fstream>
#include <cstdlib>
#include "InputParser.cpp"



using namespace std;

struct T {
	double x;
	int y;
}coord, tm1;
struct TN {
	int X;
	int x;
	int y;
};
struct comp1 {
	bool operator()(struct T cr1, struct T cr2) const {
		return cr1.x < cr2.x;
	}
};

struct cfg
{
	bool show_dims, show_max_dims, show_arrows;
	string file_boxes, file_arrows, o, colors, bw, aw, gr_arrows;
};

map <vector <int>, vector <vector <int>>> arrow;
map <vector <int>, set <vector <int>>> way1;
map <vector <int>, int> way;
map <vector <int>, T> colst, result;
map <vector< vector <int>>, int> col_arrows;
vector< vector <int>> dpair;
map <T, vector <vector <int>>, comp1> repeat[100];
vector <int> Jadn[100];
vector <int> ocornt;
vector <int> Junt;
vector <int> diag;
vector <int> diag1;
set <map <vector <int>, T>> print;
int N, k, istr, istr1;
string str, str1, color;

ofstream outf("SomeText.txt");
ofstream outf1("SomeText1.txt");
ofstream outf2("SomeText2.txt");
ofstream outf3("N.txt");
ofstream outf4("Jadn.txt");
ofstream outf5("JadnArrows.txt");
ifstream inf("output.txt");

void printusageandexit()
{
	cout << "\nYOUNG GRAPH\n\n";
	cout << "USAGE:\n";
	cout << "./YoungGraph [options]\n\n";
	cout << "OPTIONS:\n";
	cout << "-num    Num of floors\n";
	cout << "-show_dims        Show dimensions\n";
	cout << "-show_max_dims    Show max dimensions on floors\n";
	cout << "-show_arrows      Show arrows\n";
	cout << "-file_boxes       Input file with coords\n";
	cout << "-file_arrows      Input file with arrows\n";
	cout << "-o                Output graph file name\n";
	cout << "-colors           Input file with colors\n";
	cout << "-aw               Arrows width\n";
	cout << "-bw               Boxes lines width\n";
	cout << "-gr_arrows        Input file with greedy diagrams\n";
	exit(1);
};


void bf(map <vector <int>, T> cols, vector <int> Jun, vector <int> ocorn, int n) {
	if (auto it = result.find(Jun) == result.end()) {
		tm1.x = cols[Jun].x;
		tm1.y = cols[Jun].y;
		repeat[n][tm1].push_back(Jun);
	}
	
	result[Jun].x = cols[Jun].x;
	result[Jun].y = cols[Jun].y;
	if (n + 1 == N) {
		return;
	}
	
	for (int i = 0; i < ocorn.size(); i++) {
		if (ocorn[i] == 1) {
			vector <int> ocorn1;
			vector <int> Jun1;
			map <vector <int>, T> cols1;
			Jun1 = Jun;
			cols1 = cols;
			ocorn1 = ocorn;
			if (i + 1 < ocorn.size()) {
				Jun1[i]++;
				arrow[Jun].push_back(Jun1);
				way1[Jun].insert(Jun1);
				cols1[Jun1].y = cols1[Jun].y - (n + 3);
				if ((i + 1) - (Jun1[i]) == 0) cols1[Jun1].x = cols1[Jun].x;
				else cols1[Jun1].x = cols1[Jun].x + ((i + 1) - (Jun1[i]));
				ocorn1[i + 1] = 1;
				if (i > 0) {
					if (Jun1[i - 1] == Jun1[i]) ocorn1[i] = 0;
				}
				if (auto it = result.find(Jun1) == result.end()) bf(cols1, Jun1, ocorn1, n + 1);
			}
			else {
				Jun1.push_back(1);
				arrow[Jun].push_back(Jun1);
				way1[Jun].insert(Jun1);
				if (Jun1[i - 1] == 1) ocorn1[i] = 0;
				cols1[Jun1].y = cols1[Jun].y - (n + 3);
				if ((i + 1) - (1) == 0) cols1[Jun1].x = cols1[Jun].x;
				else cols1[Jun1].x = cols1[Jun].x + ((i + 1) - (1));
				ocorn1.push_back(1);
				if (auto it = result.find(Jun1) == result.end()) bf(cols1, Jun1, ocorn1, n + 1);
			}
		}
	}
}

int main(int argc, char** argv) {
	
	string s_d_string, s_m_d_string, s_a_string;
	cfg cfg;
	
	if(argc < 2)
		printusageandexit();
	InputParser parser(argc, argv);
	
	parser.get_int("-num", N);
	cfg.show_dims = parser.flag_exists("-show_dims");
	cfg.show_max_dims = parser.flag_exists("-show_max_dims");
	cfg.show_arrows = parser.flag_exists("-show_arrows");
	cfg.gr_arrows = parser.flag_exists("-gr_arrows");
	parser.get_string("-o", cfg.o);
	parser.get_string("-color", cfg.colors);
	parser.get_string("-file_boxes", cfg.file_boxes);
	parser.get_string("-file_arrows", cfg.file_arrows);
	parser.get_string("-aw", cfg.aw);
	parser.get_string("-bw", cfg.bw);
	parser.get_string("-gr_arrows", cfg.gr_arrows);
	
	ifstream inf1(cfg.gr_arrows);
	getline(inf1, str);
	for(int i = 0; i < str.size(); i++) {
		if(i % 2 == 0) {
			istr1 = str[i] - '0';
			diag.push_back(istr1);
		}		
	}
	while(!inf1.eof()) {
		dpair.push_back(diag);
		diag.clear();
		getline(inf1, str);
		for(int i = 0; i < str.size(); i++) {
			if(i % 2 == 0) {
				istr1 = str[i] - '0';
				diag.push_back(istr1);
			}	
		}
		dpair.push_back(diag);
		col_arrows[dpair];
		dpair.clear();
	}
			
	if(((cfg.file_boxes.length() == 0)&&(cfg.file_arrows.length() != 0))||
		((cfg.file_boxes.length() != 0)&&(cfg.file_arrows.length() == 0)))
	{
		cout << endl << "file_boxes or file_arrows not entered" << endl;
		exit(1);
	};

	
	if((cfg.file_boxes.length() != 0)&&(cfg.file_arrows.length() != 0)) ;
	else
	{
		if(N == 0)
		{
			cout << "num not entered" << endl;
			exit(1);
		};
		coord.x = 1, coord.y = 0;
		Junt.push_back(1);
		colst[Junt] = coord;
		way[Junt] = 1;
		outf3 << N << endl;
		ocornt.push_back(1), ocornt.push_back(1);
		bf(colst, Junt, ocornt, 0);
		for (auto it = way1.begin(); it != way1.end(); ++it) {
			for (auto iter = (*it).second.begin(); iter != (*it).second.end(); iter++) {
				way[(*iter)] += way[(*it).first];
			}
		}
		for (int k = 0; k < N; k++) {
			double ots = 0;
			double sdv = 0;
			for (auto it = repeat[k].begin(); it != repeat[k].end(); ++it) {
				for (int i = 0; i < (*it).second.size(); i++) {
					result[(*it).second[i]].x = ots;
					ots += k + 2;
					sdv = result[(*it).second[i]].x / 2;
				}
			}
			for (auto it = repeat[k].begin(); it != repeat[k].end(); ++it) {
				for (int i = 0; i < (*it).second.size(); i++) {
					result[(*it).second[i]].x -= sdv;
				}
			}
			/*int sum = 0, elem;
			while (sum != k + 1) {
				inf >> elem;
				sum += elem;
				Jadn[k].push_back(elem);
			}*/
			
		}
		int opred = 0;
		for (auto it = result.begin(); it != result.end(); ++it) {
			for (int i = 0; i < (*it).first.size(); i++) {
				for (int j = 0; j < (*it).first[i]; j++) {
					outf << (*it).second.x + i << " " << (*it).second.y + j << " |" << way[(*it).first] << endl;
					if ((*it).first == Jadn[opred]) {
						outf4 << (*it).second.x + i << " " << (*it).second.y + j <<  endl;
					}
				}
			}
			if ((*it).first == Jadn[opred]) opred++;
		}
		for (auto it = arrow.begin(); it != arrow.end(); ++it) {
			for (int i = 0; i < (*it).second.size(); i++) {
				dpair.push_back((*it).first);
				dpair.push_back((*it).second[i]);
				if(col_arrows.find(dpair) != col_arrows.end()) {
					outf5 << result[(*it).first].x << " " << result[(*it).first].y << endl;
					outf5 << result[(*it).second[i]].x << " " << result[(*it).second[i]].y + (*it).second[i][0] << endl;
				}
				dpair.clear();
				outf2 << result[(*it).first].x << " " << result[(*it).first].y << endl;
				outf2 << result[(*it).second[i]].x << " " << result[(*it).second[i]].y + (*it).second[i][0] << endl;
			}
			
		
		
		}
	};
	if(cfg.show_dims) s_d_string = "1";
	else s_d_string = "0";
	if(cfg.show_max_dims) s_m_d_string = "1";
	else s_m_d_string = "0";
	if(cfg.show_arrows) s_a_string = "1";
	else s_a_string = "0";
	if(cfg.file_boxes.length() == 0) cfg.file_boxes = "0";
	if(cfg.file_arrows.length() == 0) cfg.file_arrows = "0";
	if(cfg.o.length() == 0) cfg.o = "0";
	if(cfg.bw.length() == 0) cfg.bw = "0";
	if(cfg.aw.length() == 0) cfg.aw = "0";
	if(cfg.colors.length() == 0) cfg.colors = "0";
	if(cfg.gr_arrows.length() == 0) cfg.gr_arrows = "0";
	
	string cmd = "python3 graphs_and_arrows.py " + s_d_string + " " + s_m_d_string + " " + s_a_string + " " + cfg.file_boxes + " " + cfg.file_arrows + " " + cfg.o + " " + cfg.colors + " " + cfg.aw + " " + cfg.bw + " " + cfg.gr_arrows;

	system(cmd.c_str());
	
	return 0;
}
