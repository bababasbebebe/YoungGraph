from math import sqrt
import sys
import os
import matplotlib.pyplot as plt
from matplotlib import transforms
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
import matplotlib.patches as patches
import matplotlib.cm as cm
import Dyefile
import Sortfile
import CoordsAndColors
import time
jadn_present = []
jadn_need = []

N = 6

with open("test.txt", "r") as f1, open("SortedCoordsAndDims.txt", "r") as f2:
	for line in f1:
		if line[0] == " ":
			floor = int(line[1:line.find('f')-1])
			color = line[line.find('f'):]
		else:
			j = 0
			for i in range(len(line)-1):
				if i%2 == 0:
					jadn_need.append(line[i])
					j += 1
					
			print(len(jadn_need))
			jadn_need.clear()
			'''
		floor_check = N
		boxes_in_line = 0
		for line in f2:
			if floor_check == N - floor - 1:
				if boxes_in_line == len(jadn_need)
				
			elif floor_check < N:
				break
			else:
				floor_check -= 1
		jadn_need.clear()
#		if len(line) == 1:
#			print(" ")
#		else:
#			print(line)
#		for line1 in f2:
#			print(line1)
#		f2.seek(0)
	

#	for line in f:
#		if len(line) == 1:
#			with open("SortedCoordsAndDims.txt", "r") as f2:
			'''
			
